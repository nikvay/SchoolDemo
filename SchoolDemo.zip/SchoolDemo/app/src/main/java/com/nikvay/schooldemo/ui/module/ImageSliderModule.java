package com.nikvay.schooldemo.ui.module;

public class ImageSliderModule {
    int imageUrl;

    public ImageSliderModule(int imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(int imageUrl) {
        this.imageUrl = imageUrl;
    }
}
