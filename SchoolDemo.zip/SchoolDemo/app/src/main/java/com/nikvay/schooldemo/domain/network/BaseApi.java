package com.nikvay.schooldemo.domain.network;


public class BaseApi {

    public static String BASE_URL = "http://nikvay.com/demo/fastconnect/";   // demo another

//    public static String BASE_URL = "http://cnpmasterapp.com/fast-connect/";   // test another
   // public static String BASE_URL = "http://nikvay.com/demo/fastconnect/";   // demo another

}