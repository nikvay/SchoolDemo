package com.nikvay.schooldemo.domain.module;

public class LibraryStudentModule {
    private String full_name;
    private String roll_num;
    private String issue_date;
    private String division_name;
    private String id;
    private String book_id;
    private String book_name;
    private String class_name;
    private String return_date;

    public String getRoll_num() {
        return roll_num;
    }

    public void setRoll_num(String roll_num) {
        this.roll_num = roll_num;
    }

    public String getFull_name ()
    {
        return full_name;
    }

    public void setFull_name (String full_name)
    {
        this.full_name = full_name;
    }

    public String getIssue_date ()
    {
        return issue_date;
    }

    public void setIssue_date (String issue_date)
    {
        this.issue_date = issue_date;
    }

    public String getDivision_name ()
    {
        return division_name;
    }

    public void setDivision_name (String division_name)
    {
        this.division_name = division_name;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getBook_id ()
    {
        return book_id;
    }

    public void setBook_id (String book_id)
    {
        this.book_id = book_id;
    }

    public String getBook_name ()
    {
        return book_name;
    }

    public void setBook_name (String book_name)
    {
        this.book_name = book_name;
    }

    public String getClass_name ()
    {
        return class_name;
    }

    public void setClass_name (String class_name)
    {
        this.class_name = class_name;
    }

    public String getReturn_date ()
    {
        return return_date;
    }

    public void setReturn_date (String return_date)
    {
        this.return_date = return_date;
    }

}
