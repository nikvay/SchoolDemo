package com.nikvay.schooldemo.domain.module;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class LoginModule {
    private String email_id;
    private String full_name;
    private String user_id;
    private String user_name;
    private String division_name;
    private String contact_number2;
    private String contact_number1;
    private String class_name;
    private String type;
    private String class_id;
    private String division_id;

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getDivision_name() {
        return division_name;
    }

    public void setDivision_name(String division_name) {
        this.division_name = division_name;
    }

    public String getContact_number2() {
        return contact_number2;
    }

    public void setContact_number2(String contact_number2) {
        this.contact_number2 = contact_number2;
    }

    public String getContact_number1() {
        return contact_number1;
    }

    public void setContact_number1(String contact_number1) {
        this.contact_number1 = contact_number1;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getDivision_id() {
        return division_id;
    }

    public void setDivision_id(String division_id) {
        this.division_id = division_id;
    }
}
