package com.nikvay.schooldemo.ui.module;

public class LocationModule {
    private boolean locationOnOff=false;

    public boolean isLocationOnOff() {
        return locationOnOff;
    }

    public void setLocationOnOff(boolean locationOnOff) {
        this.locationOnOff = locationOnOff;
    }
}
