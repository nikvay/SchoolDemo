package com.nikvay.schooldemo.domain.module;

public class TimeTableModule {
    private String extension;
    private String uploaded_by_admin;
    private String class_id;
    private String note_document;
    private String uploaded_date;
    private String division_id;
    private String id;
    private String title;
    private String type;

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getUploaded_by_admin() {
        return uploaded_by_admin;
    }

    public void setUploaded_by_admin(String uploaded_by_admin) {
        this.uploaded_by_admin = uploaded_by_admin;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

    public String getNote_document() {
        return note_document;
    }

    public void setNote_document(String note_document) {
        this.note_document = note_document;
    }

    public String getUploaded_date() {
        return uploaded_date;
    }

    public void setUploaded_date(String uploaded_date) {
        this.uploaded_date = uploaded_date;
    }

    public String getDivision_id() {
        return division_id;
    }

    public void setDivision_id(String division_id) {
        this.division_id = division_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
