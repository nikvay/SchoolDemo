package com.nikvay.schooldemo.utils;

public interface SuccessDialogClosed {
    public void dialogClosed(boolean mClosed);
}
