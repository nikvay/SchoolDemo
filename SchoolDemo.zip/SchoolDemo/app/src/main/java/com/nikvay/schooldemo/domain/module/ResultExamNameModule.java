package com.nikvay.schooldemo.domain.module;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ResultExamNameModule
{
    String sub1,total_marks_1,obtain_marks_1,sub2,total_marks_2,obtain_marks_2,
            sub3,total_marks_3,obtain_marks_3,
            sub4,total_marks_4,obtain_marks_4,sub5,total_marks_5,obtain_marks_5;

    public ResultExamNameModule(String sub1, String total_marks_1, String obtain_marks_1, String sub2, String total_marks_2, String obtain_marks_2, String sub3, String total_marks_3, String obtain_marks_3, String sub4, String total_marks_4, String obtain_marks_4, String sub5, String total_marks_5, String obtain_marks_5) {

        this.sub1 = sub1;
        this.total_marks_1 = total_marks_1;
        this.obtain_marks_1 = obtain_marks_1;
        this.sub2 = sub2;
        this.total_marks_2 = total_marks_2;
        this.obtain_marks_2 = obtain_marks_2;
        this.sub3 = sub3;
        this.total_marks_3 = total_marks_3;
        this.obtain_marks_3 = obtain_marks_3;
        this.sub4 = sub4;
        this.total_marks_4 = total_marks_4;
        this.obtain_marks_4 = obtain_marks_4;
        this.sub5 = sub5;
        this.total_marks_5 = total_marks_5;
        this.obtain_marks_5 = obtain_marks_5;
    }

    public String getSub1() {
        return sub1;
    }

    public void setSub1(String sub1) {
        this.sub1 = sub1;
    }

    public String getTotal_marks_1() {
        return total_marks_1;
    }

    public void setTotal_marks_1(String total_marks_1) {
        this.total_marks_1 = total_marks_1;
    }

    public String getObtain_marks_1() {
        return obtain_marks_1;
    }

    public void setObtain_marks_1(String obtain_marks_1) {
        this.obtain_marks_1 = obtain_marks_1;
    }

    public String getSub2() {
        return sub2;
    }

    public void setSub2(String sub2) {
        this.sub2 = sub2;
    }

    public String getTotal_marks_2() {
        return total_marks_2;
    }

    public void setTotal_marks_2(String total_marks_2) {
        this.total_marks_2 = total_marks_2;
    }

    public String getObtain_marks_2() {
        return obtain_marks_2;
    }

    public void setObtain_marks_2(String obtain_marks_2) {
        this.obtain_marks_2 = obtain_marks_2;
    }

    public String getSub3() {
        return sub3;
    }

    public void setSub3(String sub3) {
        this.sub3 = sub3;
    }

    public String getTotal_marks_3() {
        return total_marks_3;
    }

    public void setTotal_marks_3(String total_marks_3) {
        this.total_marks_3 = total_marks_3;
    }

    public String getObtain_marks_3() {
        return obtain_marks_3;
    }

    public void setObtain_marks_3(String obtain_marks_3) {
        this.obtain_marks_3 = obtain_marks_3;
    }

    public String getSub4() {
        return sub4;
    }

    public void setSub4(String sub4) {
        this.sub4 = sub4;
    }

    public String getTotal_marks_4() {
        return total_marks_4;
    }

    public void setTotal_marks_4(String total_marks_4) {
        this.total_marks_4 = total_marks_4;
    }

    public String getObtain_marks_4() {
        return obtain_marks_4;
    }

    public void setObtain_marks_4(String obtain_marks_4) {
        this.obtain_marks_4 = obtain_marks_4;
    }

    public String getSub5() {
        return sub5;
    }

    public void setSub5(String sub5) {
        this.sub5 = sub5;
    }

    public String getTotal_marks_5() {
        return total_marks_5;
    }

    public void setTotal_marks_5(String total_marks_5) {
        this.total_marks_5 = total_marks_5;
    }

    public String getObtain_marks_5() {
        return obtain_marks_5;
    }

    public void setObtain_marks_5(String obtain_marks_5) {
        this.obtain_marks_5 = obtain_marks_5;
    }
}

