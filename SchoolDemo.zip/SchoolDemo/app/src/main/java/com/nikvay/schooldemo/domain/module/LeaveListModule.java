package com.nikvay.schooldemo.domain.module;

public class LeaveListModule {
    private String end_date;
    private String leave_status;
    private String user_name;
    private String class_id;
    private String division_id;
    private String student_id;
    private String leave_id;
    private String leave_description;
    private String full_name;
    private String contact_number1;
    private String leave_subject;
    private String class_name;
    private String division_name;
    private String start_date;
    private String teacher_comment;
    private String gender;

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEnd_date ()
    {
        return end_date;
    }

    public void setEnd_date (String end_date)
    {
        this.end_date = end_date;
    }

    public String getLeave_status ()
    {
        return leave_status;
    }

    public void setLeave_status (String leave_status)
    {
        this.leave_status = leave_status;
    }

    public String getUser_name ()
    {
        return user_name;
    }

    public void setUser_name (String user_name)
    {
        this.user_name = user_name;
    }

    public String getClass_id ()
    {
        return class_id;
    }

    public void setClass_id (String class_id)
    {
        this.class_id = class_id;
    }

    public String getDivision_id ()
    {
        return division_id;
    }

    public void setDivision_id (String division_id)
    {
        this.division_id = division_id;
    }

    public String getStudent_id ()
    {
        return student_id;
    }

    public void setStudent_id (String student_id)
    {
        this.student_id = student_id;
    }

    public String getLeave_id ()
    {
        return leave_id;
    }

    public void setLeave_id (String leave_id)
    {
        this.leave_id = leave_id;
    }

    public String getLeave_description ()
    {
        return leave_description;
    }

    public void setLeave_description (String leave_description)
    {
        this.leave_description = leave_description;
    }

    public String getFull_name ()
    {
        return full_name;
    }

    public void setFull_name (String full_name)
    {
        this.full_name = full_name;
    }

    public String getContact_number1 ()
    {
        return contact_number1;
    }

    public void setContact_number1 (String contact_number1)
    {
        this.contact_number1 = contact_number1;
    }

    public String getLeave_subject ()
    {
        return leave_subject;
    }

    public void setLeave_subject (String leave_subject)
    {
        this.leave_subject = leave_subject;
    }

    public String getClass_name ()
    {
        return class_name;
    }

    public void setClass_name (String class_name)
    {
        this.class_name = class_name;
    }

    public String getDivision_name() {
        return division_name;
    }

    public void setDivision_name(String division_name) {
        this.division_name = division_name;
    }

    public String getStart_date ()
    {
        return start_date;
    }

    public void setStart_date (String start_date)
    {
        this.start_date = start_date;
    }

    public String getTeacher_comment() {
        return teacher_comment;
    }

    public void setTeacher_comment(String teacher_comment) {
        this.teacher_comment = teacher_comment;
    }
}
