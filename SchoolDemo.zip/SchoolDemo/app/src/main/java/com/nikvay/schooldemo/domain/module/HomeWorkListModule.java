package com.nikvay.schooldemo.domain.module;

public class HomeWorkListModule {

    private String date;
    private String submission_date;
    private String img_name;
    private String teacher_id;
    private String class_id;
    private String description;
    private String division_id;
    private String id;
    private String time;
    private String title;
    private String given_date;
    private String class_name;
    private String division_name;

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getDivision_name() {
        return division_name;
    }

    public void setDivision_name(String division_name) {
        this.division_name = division_name;
    }

    public String getDate ()
    {
        return date;
    }

    public void setDate (String date)
    {
        this.date = date;
    }

    public String getSubmission_date ()
    {
        return submission_date;
    }

    public void setSubmission_date (String submission_date)
    {
        this.submission_date = submission_date;
    }

    public String getImg_name ()
    {
        return img_name;
    }

    public void setImg_name (String img_name)
    {
        this.img_name = img_name;
    }

    public String getTeacher_id ()
    {
        return teacher_id;
    }

    public void setTeacher_id (String teacher_id)
    {
        this.teacher_id = teacher_id;
    }

    public String getClass_id ()
    {
        return class_id;
    }

    public void setClass_id (String class_id)
    {
        this.class_id = class_id;
    }

    public String getDescription ()
    {
        return description;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public String getDivision_id ()
    {
        return division_id;
    }

    public void setDivision_id (String division_id)
    {
        this.division_id = division_id;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getTime ()
    {
        return time;
    }

    public void setTime (String time)
    {
        this.time = time;
    }

    public String getTitle ()
    {
        return title;
    }

    public void setTitle (String title)
    {
        this.title = title;
    }

    public String getGiven_date ()
    {
        return given_date;
    }

    public void setGiven_date (String given_date)
    {
        this.given_date = given_date;
    }

}
