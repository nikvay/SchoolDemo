package com.nikvay.schooldemo.domain.module;

public class ResultMarkModule {
    private String subject_name;
    private String marks_obtain;
    private String out_of_marks;

    public String getSubject_name ()
    {
        return subject_name;
    }

    public void setSubject_name (String subject_name)
    {
        this.subject_name = subject_name;
    }

    public String getMarks_obtain ()
    {
        return marks_obtain;
    }

    public void setMarks_obtain (String marks_obtain)
    {
        this.marks_obtain = marks_obtain;
    }

    public String getOut_of_marks ()
    {
        return out_of_marks;
    }

    public void setOut_of_marks (String out_of_marks)
    {
        this.out_of_marks = out_of_marks;
    }
}
